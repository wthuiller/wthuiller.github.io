/* $Id: ranlxd.h,v 1.1.1.1 2003/01/07 10:58:44 urbach Exp $ */

#ifndef _RANLXD_H
#define _RANLXD_H


extern void ranlxd(double * const r, const int n);
extern void rnormal(double * r, const int n);
extern int rpoisson(double L);
extern int random(const unsigned int i);
extern void rlxd_init(const int level, const int seed);
extern void rlxd_get(int * const state);
extern void rlxd_reset(const int * state);


#endif
