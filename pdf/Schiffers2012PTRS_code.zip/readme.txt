
ReadMe

============================================================================
				
    	    SPATIALLY EXPLICIT, ALLELIC SIMULATION MODEL 0.1

	  	  Katja Schiffers, Justin Travis
				  
			     April 2012

This is the ReadMe file for an individual-based, spatially explicit model
that simulates the allele dynamics of a population of an arbitrary annual 
plant species under variable environment. 
Environment is represented by two uncorrelated variables that can 
change both in time and across space. Evolutionary processes comprise 
recombination, mutation and hard selection; ecological processes 
include reproduction, dispersal and mortality (density and age 
dependent).

The full description of the model can be found in the manuscript: 
'Limited evolutionary rescue under habitat heterogeneity" by 
Schiffers K, Bourne E, Lavergne S, Thuiller W and Travis JMJ (2012)
Philosophical Transactions of the Royal Society B

This ReadMe file explains how to to acquire and compile the source code, 
how to get started and how to reproduce the results presented in the 
above publication.


============================================================================

This file contains:

1. General information:
        A. Disclaimer and copyright
        B. Acknowledgements
        C. Contact addresses

2. Getting started:
        A. Downloading and installing the software
	B. Adapting model parameters
        C. Running the model
	D. Interpreting the result files
	E. Known bugs

3.  Example scenarios
        A. Reproducing the results presented in the 
	   associated publication


============================================================================
 1. GENERAL INFORMATION:
============================================================================

A. Disclaimer and Copyright

Copyright Katja Schiffers and Justin Travis, 2012

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details
<http://www.gnu.org/licenses/>.


============================================================================

B. Acknowledgements

The software was developed by Katja Schiffers and Justin Travis 
with help from Elisabeth Bourne and Carsten Urbach.

The project was supported by a Marie Curie Intra European Fellowshipto KS within the 7th European Community Framework Programme.


============================================================================

C. Contact Address:

    Katja Schiffers
    email: katja.schiffers@gmail.com 


============================================================================
 2. GETTING STARTED:
============================================================================

A. Installing the Software

This model was developed on a Unix workstation, but should be principally
platform independent.
For compiling and running the model you will need

1) a C++ compiler like the GNU compiler g++,
2) the program 'make' and
3) a terminal or shell for command line control.


The source-code you need for running the model is contained in the 
compressed file 'Allele_Model.zip' distributed as supplementary material 
of the manuscript 'Limited evolutionary rescue under habitat heterogeneity'
by Schiffers et al. (2012) Philosophical Transactions of the Royal Society B.
For a maintained versions of the model, you can pick up the source code
from the following web-page:

www.katja-schiffers.eu/docs/Allele_Model.zip

Create a new directory, put the file 'Allele_Model.zip' into that directory
and uncompress the source code. The current directory should then contain a 
Makefile and a set of source-code and header files (main.cpp, main.o, 
ranlxd.cpp and ranlxd.o). 


============================================================================

B. Adapting model parameters

All model parameters can be found in the file 'main.cpp' in lines 39 - 90.

SIMULATIONS
Rep		- the number of simulations with same parameter setting 
Gen 		- the number of generations simulated 

GRID
XSIZE		- size of the grid in x direction, should be 2*2^n
YSIZE		- size of grid in y direction, should be 2*2^n
patchsize 	- side length of grid cell

ENVIRONMENT
fractal 	- is landscape fractal? otherwise homogeneous/gradual
pow2x 		- parameter for fractal environment, the n of XSIZE
pow2y		- parameter for fractal environment, the n of YSIZE
H		- Hurst exponent (between 0 = rough surface and 1)
env_max		- maximal amplitude of fractal landscapes = heterogeneity

CLIMATE
init_climate 	- initial climate value (in the south if climate gradient)
gradient	- difference in climate value in the north and south
env_gradient	- same for other env condition if fractal==false
start_climate 	- generation at which change in climate starts
end_climate 	- generation at which change in climate ends
shift_climate 	- total shift in climate value 
DEMOGRAPHY
K		- carrying capacity of one patch/grid cell
IPP		- number of individuals per patch for initialization
offsp 		- mean no of offspring (Poisson distributed)
mean_disp	- mean dispersal distance of inds (lognormal kernel)
pollen_disp 	- mean dispersal distance of pollen (lognormal kernel)
loc 		- location parameter for both dispersal kernels
scale		- shape parameter for dispersal kernels (between 0 and 1)
selfing		- fraction of ovules that is self-fertilized
ddselfing	- density dependent selfing? When selfing=0

EVOLUTION
adapted		- are individuals locally adapted for initialization?
stand_var_env	- variance of environmental phenotype for initialization
stand_var_clim	- same for climate phenotype
varClim		- breadth of the climatic niche (var of Normal distribution)
varEnv		- breadth of the environmental niche
mut_rate	- mutation rate per locus and generation
linkage		- are climate and env loci placed on the same chromosome?
no_cross	- average number of crossovers if linkage==true
inf_cross 	- no linkage between any loci?
mut_clim	- variance of effects of mutations at climate loci
mut_env		- variance of effects of mutations at environmental loci
MAXL		- total number of loci
ENVL		- number of loci coding for environment


============================================================================

C. Running the model

1) After adjusting the model parameters, set the path in which the result
files should be placed. You find the respective line of code in the file 
main.cpp, line 167, beginning of the function 'main'.
Make sure that this directory exists otherwise create it.

2) Save the main.cpp file

3) Compile the source code by typing 

      	make  

in the shell in the directory where the Makefile is located. This
creates the executable file 'run'.

4) To start the simulations type

	./run

in the shell. The program writes out the current generation to the
standard output. This way you can follow the progress of the simulations.


============================================================================

D. Interpreting the result files

When the simulations are finished, you will find several output files in
the path specified in main.cpp

1) parameters.csv - all chosen parameter values

2) popsize.csv - one line per generation with the parameter values for 
env_max, mean_disp, and linkage, the number of the replicate, the seed 
drawn to initialize the random number generator (setting the the seed to 
that value in the source code, line 227, will allow you to re-run the 
simulation with the exact same random numbers) and the current population 
size

3) dynamics_H_x_D_x_L_x.csv - where H stands for the parameter env_max, 
D for mean_dist and L for linkage
one line per generation with: the replicate, the generation, the actual 
climate, the average climate fitness of all individuals, the variance in 
that fitness, the average environmental fitness of all individuals, the 
variance in that fitness and the average overall fitness of all individuals 
and its variance and the population size

4) cgeno_H_x_D_x_L_x.csv - one line per generation: the climatic genotypes
of all individuals

5) egeno_H_x_D_x_L_x.csv - one line per generation: the environmental
genotypes of all individuals


============================================================================

E. Known bugs

Memory for holding individuals is not allocated dynamically, yet. Thus, when 
the carrying capacity, the number of offspring or the average dispersal
distance is increased, memory allocation errors might occur. We will work
on that for the next version of the model.


============================================================================
 3.  EXAMPLE SCENARIOS
============================================================================


For reproducing the results presented in the associated publication,
four model parameters were varied (two of which in parallel):

env_max	-  0, 1, 2, 3, 4, 5
mean_disp and pollen_dips (in parallel) - 0,1, 0.2, 0.4, 0.8, 1.6, 3.2, 6,4  
inf_cross - false, true

All other parameters were set, as given in the source-code.

For an easier handling of the simulations, it is possible to create loops
within the main-function for an automatic increment of these parameter 
values. Since the result files save the respective combinations of these 
parameters (either in the file-name or in the file itself) it will be 
possible to distinguish the scenarios afterwards.

* Note that a single run of 500 generations with the default parameter
values will take about 2-3 minutes on a 2.8 GHz Intel Core i5 processor.
 







