
//  Allelic simulation model
 
//  Copyright Katja Schiffers and Justin Travis, 
//  2012

//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  For details of the GNU General Public License
//  see <http://www.gnu.org/licenses/>.


#pragma hdrstop

#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <fstream>         
#include <iostream> 
#include <sstream>
#include <algorithm>

#include "ranlxd.h"

using namespace std;


///////////////////// PARAMETERS ///////////////////////////////////////////////////////////

ostringstream path;           // path in which results are saved, set at beginning of main

// simulations
int Rep = 100, rep;           // number and counter of replicates
int Gen = 500, gen;           // number and counter of generations 

// grid
const int XSIZE = 32;         // size of grid in x direction, for fractal on torus: 2*2^n
const int YSIZE = 32;         // size of grid in y direction, for fractal on torus: 2*2^n
double patchsize = 1.0;       // side length of grid cell

// environment
bool fractal = true;          // is landscape fractal? otherwise homogeneous/gradual
int pow2x = 4;                // parameter for fractal environment, the n above
int pow2y = 4;                // parameter for fractal environment
double H = 0.2;               // Hurst exponent, 0 = no reduction of range of random number
int env_max = 2;              // range of environmental conditions = habitat heterogeneity

// climate
double init_climate = 25.0;   // representing climate in the south
double gradient = 0.0;        // gradient of climatic conditions
double env_gradient = 0.0;    // gradient of environmental conditions when fractal==false
int start_climate = 200;      // generation at which change in climate starts
int end_climate = 300;        // generation at which change in climate ends
double shift_climate = 2.0;   // total shift of climate

// demography
const int K = 5;              // carrying capacity of one patch
const int IPP = 3;            // no of Individuals per patch for initialisation
double offsp = 100.0;         // mean no of offspring
double mean_disp = 0.4;       // mean dispersal distance of individuals
double pollen_disp = 0.4;     // mean dispersal distance of pollen
double loc = 0.0;             // location parameter for lognormal dispersal kernel
double scale = 0.50;          // shape parameter for lognormal dispersal kernel
double selfing = 0.0;         // fraction of self-fertilization
bool ddselfing = false;       // density dependent selfing?

// evolution
bool adapted = true;          // are individuals locally adapted to environment for initialisation?
double stand_var_env = 0.01;  // variance of env phenotype for initialisation
double stand_var_clim = 0.01; // same for climate phenotype
double varClim = 0.1;         // breadth of the climatic niche (Gausse-shape)
double varEnv = 0.1;          // breadth of the environmental niche (Gausse-shape)
double mut_rate = 0.000001;   // mutation rate
bool linkage = true;          // are loci linked on chromosomes?
int no_cross = 0;             // average number of crossovers if linkage==true
bool inf_cross = false;       // infinite crossovers = no linkage between any loci?
double mut_clim = 0.2;        // variance of normal dist for effects of mutations at climate loci
double mut_env = 0.2;         // variance of normal dist for effects of mutations at environm  loci
const int MAXL = 30;          // length of chromosome
const int ENVL = 15;          // number of loci coding for environment

///////////////////////////////////////////////////////////////////////////////////////////////


double climate = init_climate; 
double climate_fit = 0.0;
double env_fit = 0.0;
double mean_fit = 0.0;
double var, var_e, var_c = 0.0;

struct patch{                 // one grid cell
  double environment;         // value for environmental conditions
  double climate;             // climatic value
  int no_inds;                // number of adult individuals
  int no_offs;                // number of offspring before selection
  int no_surv;                // number of survivors of selection
  int no_ext;                 // number of extinctions of individuals
  int inds_patch[10000*K];    // list with IDs of individuals
  double cpheno;              // average climatic phenotype of individuals
  double epheno;              // average environmental phenotype of individuals
  double maladapt;            // level of maladaptation of individuals
};

struct individual{
  int alive;                  // 1 for alive, 0 for dead
  int x_pos, y_pos;           // position on landscape grid
  double x_cont, y_cont;      // continuous x, y coordinates
  double copy1[MAXL];         // loci - maternal
  double copy2[MAXL];         // loci - paternal
  double epheno;              // phenotype for environment
  double cpheno;              // phenotype for climate
  double fitness;             // total fitness of individual
  double climate_fit;         // fitness related to climate
  double env_fit;             // fitness related to environment
};

patch land[XSIZE][YSIZE];             // the landscape
individual inds[XSIZE*YSIZE*K*15];    // list of all individuals
individual tempI[XSIZE*YSIZE*K*500];  // temporary vector to hold individuals
int environm[ENVL];                   // to store pos of genes coding for adap to environm
double tcopy[MAXL];                   // to store temporary copy of chromosomes
int Psize, tPsize;                    // population size and temporary population size
int seed;                             // random seed


void initialise(void); 
void climate_change(void);      
void recombination(int);     
void reproduction(void);
void mutation(void);
void dispersal(void);
void selection(void);
void dd_survival(void);
void output(void);

template <typename T> 
T **AllocateDynamicArray(int nRows, int nCols)
{
     T **dynamicArray;
  
     dynamicArray = new T*[nRows];
     for( int i = 0 ; i < nRows ; i++ )
       dynamicArray[i] = new T [nCols];
     
     return dynamicArray;
}

template <typename T>
void FreeDynamicArray(T** dArray)
{
      delete [] *dArray;
      delete [] dArray;
}


//----------------------------------------------------------------------------------

int main(){ 

  path << "path_in_which_results_are_saved/";

  ostringstream file1, file2; 
  file1 << path.str().c_str() << "parameters.csv";
  file2 << path.str().c_str() << "popsizes.csv";
  
  ofstream parameters(file1.str().c_str());
  ofstream popsizes(file2.str().c_str());

  // writing out model parameters used into file 'parameters.csv'	
  parameters << "environment " << endl 
             << "fractal " << fractal << endl
	     << "H " << H << endl
	     << "env_max " << env_max << endl
	     << "climate " << init_climate << endl
	     << "gradient "<< gradient << endl
	     << "env_gradient " << env_gradient << endl
	     << "start_climate " << start_climate << endl
	     << "end_climate " <<  end_climate << endl
	     << "shift_climate " << shift_climate << endl
	     << "demography" << endl
	     << "K " << K << endl
	     << "IPP " <<  IPP << endl
	     << "offsp " << offsp << endl
	     << "mean_disp " << mean_disp << endl
	     << "loc " << loc << endl
	     << "scale " << scale << endl
	     << "pollen_disp " << pollen_disp << endl
	     << "selfing " << selfing << endl
	     << "ddsefing " << ddselfing << endl
	     << "evolution " << endl
	     << "local_adapt " <<  local_adapt << endl
	     << "stand_var_clim " << stand_var_clim << endl
	     << "stand_var_env " << stand_var_env << endl
	     << "varClim " <<  varClim << endl
	     << "varEnv " << varEnv <<endl
	     << "mut_rate " <<  mut_rate << endl
	     << "crossovers " << no_cross << endl
	     << "mut_clim " << mut_clim << endl
	     << "mut_env " <<  mut_env << endl
	     << "MAXL " << MAXL << endl
	     << "ENVL " << ENVL << endl; 
  parameters.close();

  popsizes << "range dispersal linkage rep seed popsize" << endl;

  ostringstream oss1, oss2, oss3;
  oss1 << path.str().c_str() << "dynamics_H_" << env_max << "_D_" << mean_disp << "_L_" << linkage <<".csv";
  oss2 << path.str().c_str() << "cgeno_H_" << env_max << "_D_" << mean_disp << "_L_" << linkage <<".csv";
  oss3 << path.str().c_str() << "egeno_H_" << env_max << "_D_" << mean_disp << "_L_" << linkage <<".csv";
  
  ofstream out_dyn(oss1.str().c_str());
  ofstream out_cgeno(oss2.str().c_str());
  ofstream out_egeno(oss3.str().c_str());
  
  out_dyn << "replicate generation climate climate_fit var_c env_fit var_e mean_fit var Psize" << endl;
  
  for(rep=0; rep<Rep; rep++){
    
    seed = (int)time(0); 
    rlxd_init(0, seed);
    
    int offspring = 0;
    int gen_mort = 0;
    int dens_mort = 0;
    int survivor = 0;
    climate = init_climate;
    
    initialise();
    output();
    
    for(gen=0; gen<Gen; gen++){

      out_dyn << rep+1 << " " << gen+1 << " " << climate << " " << climate_fit << " " << var_c << " " <<  env_fit 
	      << " "  << var_e << " " << mean_fit << " " << var << " " << Psize << endl;
      
      for(int i = 0; i < XSIZE*YSIZE*K*2; i++){
	if(i<Psize){
	  out_egeno << inds[i].egeno << " ";
	  out_cgeno << inds[i].cgeno << " ";
	}
	else{
	  out_egeno << "NA ";
	  out_cgeno << "NA ";
	}
      }
      out_egeno << endl;
      out_cgeno << endl; 
      
      cout << "Generation " << gen << " Population size: " << Psize << endl;
      
      climate_change(); 
      reproduction();
      mutation();
      dispersal(); 
      selection();
      dd_survival();
      output();
      
    }     // end generation - loop
    
    popsizes << env_max << " " << mean_disp << " " << linkage << " " << rep << " " << seed << " " << Psize << endl;
    
  }     // end replicate - loop
  
  out_dyn.close();
  out_egeno.close();
  out_cgeno.close();
  popsizes.close();
  return(0);
}


//--- INITIALISATION ----------------------------------------------------------------


void initialise(void){

  double r;
  double r2[2];
  double r4[4];

  for (int x = 0; x < XSIZE; x++){
    for (int y = 0; y < YSIZE; y++){
      land[x][y].no_inds = 0;
      land[x][y].no_offs = 0;
      land[x][y].no_surv = 0;
      for(int z = 0; z <= (100*K); z++){
	land[x][y].inds_patch[z] = -99;
      }
      land[x][y].epheno = 0.0;
      land[x][y].cpheno = 0.0;
      land[x][y].maladapt = 0.0;
    }
  }

  for(int i = 0; i < (XSIZE * YSIZE * K * 15); i++){
    inds[i].x_pos = -99;
    inds[i].y_pos = -99;
    inds[i].x_cont = -99.9;
    inds[i].y_cont = -99.9;
    inds[i].epheno = -99.9;
    inds[i].cpheno = -99.9;
    inds[i].fitness = -99.9;
    inds[i].climate_fit = -99.9;
    inds[i].env_fit = -99.9;
    for(int j=0; j < MAXL; j++){
      inds[i].copy1[j]= -99.9;
      inds[i].copy2[j]= -99.9;
    }
 

    tempI[i].x_pos = -99;
    tempI[i].y_pos = -99;
    tempI[i].x_cont = -99.9;
    tempI[i].y_cont = -99.9;
    inds[i].epheno = -99.9;
    inds[i].cpheno = -99.9;
    tempI[i].fitness = -99.9;
    tempI[i].climate_fit = -99.9;
    tempI[i].env_fit = -99.9;
    for(int j=0; j < MAXL; j++){
      tempI[i].copy1[j]= -99.9;
      tempI[i].copy2[j]= -99.9;
    }
  }


  climate_fit = 0.0;
  env_fit = 0.0;
  mean_fit = 0.0;
  Psize = 0;
  tPsize = 0;

  if(fractal==true){

    // define environmental conditions as fractal landscape
    
    // seed 4 corners
    int kx = XSIZE / 2;
    int ky = YSIZE / 2;
    
    int range = env_max;

    ranlxd(r4, 4);
    land[0][0].environment = round((r4[0]*range*2)-range);
    land[kx][0].environment = round((r4[1]*range*2)-range);
    land[0][ky].environment = round((r4[2]*range*2)-range);
    land[kx][ky].environment = round((r4[3]*range*2)-range);
    
    // fill other grid cells
    double i = pow2x;
    double j = pow2y;
    
    while (i > 0){       // i determines the scale
      
      // reduce range
      range = range*pow(2,-H);
      
      // calculate coordinates of next grid cells to fill
      double nx = pow(2,i); 
      kx = (nx) / 2;  
      int kx2 = 2 * kx;  
      
      double ny = pow(2,j);
      ky = (ny) / 2;
      int ky2 = 2 * ky;


      for(int ix = 0; ix <= (XSIZE-nx); ix+=(nx)){       // to move across grid
	for(int iy = 0; iy <= (YSIZE-ny); iy+=(ny)){
	  
	  int ix_minus_kx = ix - kx;
	  ix_minus_kx = fmod(ix_minus_kx+XSIZE, XSIZE);
	  int iy_minus_ky = iy - ky;
	  iy_minus_ky = fmod(iy_minus_ky+YSIZE, YSIZE);
	  int ix_plus_kx2 = ix + kx2;
	  ix_plus_kx2 = fmod(ix_plus_kx2+XSIZE, XSIZE);
	  int iy_plus_ky2 = iy + ky2;
	  iy_plus_ky2 = fmod(iy_plus_ky2+YSIZE, YSIZE);

	  // random displacement within range to be added to average value of corners
	  ranlxd(&r, 1);
	  int ran1 = round((r*range*2)-range);
	  land[ix+kx][iy+ky].environment = ((land[ix][iy].environment + land[ix][iy_plus_ky2].environment +
					     land[ix_plus_kx2][iy].environment 
					     + land[ix_plus_kx2][iy_plus_ky2].environment) / 4) + ran1;
	}
      }
      
      for(int ix = 0; ix <= (XSIZE-nx); ix+=(nx)){       // to move across grid
	for(int iy = 0; iy <= (YSIZE-ny); iy+=(ny)){
	  
	  // random displacement within range to be added to average value of corners
	  ranlxd(r2, 2);
	  int ran[2];
	  for (int i = 0; i < 2; i++){ 
	    ran[i] = round((r2[i]*range*2)-range);
	  }
	  
	  int ix_minus_kx = ix - kx;
	  ix_minus_kx = fmod(ix_minus_kx+XSIZE, XSIZE);
	  int iy_minus_ky = iy - ky;
	  iy_minus_ky = fmod(iy_minus_ky+YSIZE, YSIZE);
	  int ix_plus_kx2 = ix + kx2;
	  ix_plus_kx2 = fmod(ix_plus_kx2+XSIZE, XSIZE);
	  int iy_plus_ky2 = iy + ky2;
	  iy_plus_ky2 = fmod(iy_plus_ky2+YSIZE, YSIZE);
	  

	  land[ix][iy+ky].environment = ((land[ix][iy].environment +land[ix][iy_plus_ky2].environment +
					  land[ix+kx][iy+ky].environment
					  + land[ix_minus_kx][iy+ky].environment) / 4) + ran[0];
	  land[ix+kx][iy].environment = ((land[ix][iy].environment + land[ix+kx][iy+ky].environment +
					  land[ix_plus_kx2][iy].environment 
					  + land[ix+kx][iy_minus_ky].environment)/ 4) + ran[1];
	  
	  
	}
      }
      
      if (i==j) j--;
      i--;
    }
  }

  // ------- define climate and environment if fractal is false -------------------------

  double clim = 0.0;
  double envi = 0.0;

  for(int x=0; x < XSIZE; x++){
    if(gradient > 0.0) clim = climate - (gradient/XSIZE * x);
    else clim = climate;
    envi = 5 - (env_gradient/XSIZE * x);
    for(int y=0; y < YSIZE; y++){
      land[x][y].climate = clim;
      if(fractal==false)   land[x][y].environment = envi;
    }
  }

  // ------- fill with individuals -------------------


  // select ENVL random loci (from MAXL on the chromosome) coding for environment and store locations in environ

  if(linkage==true){
    int p=0, q;
    while(p<ENVL){
      q=random(MAXL);
      
      bool single=true;
      for(int r=0; r<ENVL; r++) if(environm[r]==q) single=false;
      
      if(single==true){
	environm[p]=q;
	p++;
      }
    }
  }
  
  else{
    for(int r=0; r<ENVL; r++){
      environm[r] = r;
    }
  }
  
  for(int x=0; x < XSIZE; x++ ){
    for(int y=0; y < YSIZE; y++){ 
      
      for(int ipp=0; ipp<IPP; ipp++){           // Ipp individuals
	inds[Psize].alive = 1;                  // ind is alive 
	inds[Psize].x_pos = x;                  // get position
	inds[Psize].y_pos = y;
	ranlxd(r2,2);
	inds[Psize].x_cont = (x * patchsize) + (r2[0]*patchsize);   // continuous x/y position
	inds[Psize].y_cont = (y * patchsize) + (r2[1]*patchsize);   // continuous x/y position
	
	for(int l=0;l<MAXL;l++){               // fill chromosomes with genes
	  bool env=false;
	  for(int e=0; e<ENVL; e++) if(l==environm[e]) env=true;
	  
	  
	  if(env==true) {
            if(adapted==false){
	      rnormal(&r, 1);
	      inds[Psize].copy1[l] = r*stand_var_env;      // adapted to mean environment
	      rnormal(&r,1);
	      inds[Psize].copy2[l] = r*stand_var_env;      // with variation
            }
            else{
	      rnormal(&r,1);
	      inds[Psize].copy1[l] = (land[x][y].environment/(ENVL*2)) + r* stand_var_env;      // adapted to local env
	      rnormal(&r,1);
	      inds[Psize].copy2[l] = (land[x][y].environment/(ENVL*2)) + r * stand_var_env;      // with variation
            }
	  }	  
	  if(env==false){ 
	    rnormal(&r, 1);
	    inds[Psize].copy1[l] = ((climate-((gradient+0.001)/3))/((MAXL-ENVL)*2)) + r * stand_var_clim;  
	    rnormal(&r, 1);
	    inds[Psize].copy2[l] = ((climate-((gradient+0.001)/3))/((MAXL-ENVL)*2)) + r * stand_var_clim;
	  }
	}
	
	land[x][y].inds_patch[land[x][y].no_inds] = Psize;    // index of inds is written in list
	land[x][y].no_inds++;                                 // one more ind in patch
	Psize++;
	
      }
    }
  }
}



// ---- CLIMATE CHANGE ---------------------------------------------------------------

void climate_change(void){
  
  if(gen >= start_climate & gen <=end_climate){
    
    for(int x=0; x < XSIZE; x++){
      for(int y=0; y < YSIZE; y++){
	land[x][y].climate = land[x][y].climate + (shift_climate/(end_climate-start_climate));
      }
    }
    climate = land[0][0].climate;
  }
}


// ----- REPRODUCTION AND DEATH OF ADULTS -----------------------------------------

void reproduction(void){

  int i, off, Off, l;
  int rmate, rm, f_x, f_y;
  double rdist, dist;
  int self, Self, outcrossed, Outcrossed;
  double newx, newy;
  bool found_cell;
  bool found_father;
  int trials;

  
  tPsize=0;                                         // counter for inds in tempI
  
  for(i=0; i<Psize; i++){                           // for each individual
    Off = rpoisson(offsp);                          // random no of offspring
    Self = round(double(Off) * selfing);            // no of self-fertilized
    Outcrossed = Off - Self;                        // no of outcrossed offspring
    
    for(self = 0; self< Self; self++){              // for each self-fertilized ovule
      tempI[tPsize].alive=1;                        // .. is alive
      tempI[tPsize].x_pos=inds[i].x_pos;            // is in the same patch as mother
      tempI[tPsize].y_pos=inds[i].y_pos;
      tempI[tPsize].x_cont=inds[i].x_cont;          // and has same coordinates
      tempI[tPsize].y_cont=inds[i].y_cont;
      
      recombination(i);                             // get gamete from mother (tcopy)
      for(l=0; l<MAXL; l++){
	tempI[tPsize].copy1[l]=tcopy[l];
      }
      
      recombination(i);                             // get second gamete from mother
      for(l=0; l<MAXL; l++){
	tempI[tPsize].copy2[l]=tcopy[l];
      }
      
      tPsize++; 
    }
    
    
    for(outcrossed=0; outcrossed<Outcrossed; outcrossed++){    // each outcrossed ovule
      
      found_cell = false;
      found_father = false;
      trials = 0;
      
      while(found_father == false && trials < 100){
	while(found_cell == false){
	  rnormal(&rdist, 1);
	  while (rdist == 1.0) rnormal(&rdist,1);
	  dist = ((exp(loc+scale*rdist))/(exp(loc+(scale*scale)/2))) * (pollen_disp/exp(loc+0.5*scale*scale));
	  if(kernel_cut == true){
	    while(dist > 3 * pollen_disp){
	      rnormal(&rdist, 1);
	      while (rdist == 1.0) rnormal(&rdist,1);
	      dist = ((exp(loc+scale*rdist))/(exp(loc+(scale*scale)/2))) * (pollen_disp/exp(loc+0.5*scale*scale));
	    }
	  }
	  double angle = random(360)*(M_PI/180);
	  
	  newx = inds[i].x_cont + cos(angle) * dist;
	  // random xcell inside x-range of gradient? -> okay
	  if(newx < (patchsize * XSIZE) && newx > 0.0 && gradient > 0.0) found_cell = true;
	  // no gradient? -> okay and calculate position on torus
	  else if(gradient==0.0){
	    newx = fmod(newx+(patchsize*XSIZE*10), (patchsize*XSIZE));	 
	    found_cell = true;
	  }
	  // otherwise new trial
	  else found_cell = false;
	  newy = inds[i].y_cont + sin(angle) * dist;
	  newy = fmod(newy+(patchsize*YSIZE*10), (patchsize*YSIZE));
	}
	if(found_cell==false) 
	if(found_cell == true){
	  f_x = int (newx / patchsize);
	  f_y = int (newy / patchsize);
	  
	  if(land[f_x][f_y].no_inds > 0){                   // if there are individuals in cell
	    rm=random(land[f_x][f_y].no_inds);              // get random no (0 - no of inds)
	    rmate=land[f_x][f_y].inds_patch[rm];            // get ID from this ind
	    
	    if(rmate!=i || ddselfing==true){
	      found_father = true;
	      
	      tempI[tPsize].alive=1;                         // .. is alive
	      tempI[tPsize].x_pos=inds[i].x_pos;             // is in the same patch as mother
	      tempI[tPsize].y_pos=inds[i].y_pos;
	      tempI[tPsize].x_cont=inds[i].x_cont;           // and has same coordinates
	      tempI[tPsize].y_cont=inds[i].y_cont;
	      
	      recombination(i);                              // get gamet from mother (tcopy)
	      for(l=0; l<MAXL; l++){
		tempI[tPsize].copy1[l]=tcopy[l];
	      }
	      
	      recombination(rmate);                           // get gamet for father
	      for(l=0; l<MAXL; l++){
		tempI[tPsize].copy2[l]=tcopy[l];
	      }
	      
	      tPsize++; 
	    }
	  }
	}
	trials++;
      }
    }
    
  }
  
  for(i=0; i < Psize; i++){                          // delete adults after repr
    inds[i].alive=-99;
    inds[i].x_pos = -99;
    inds[i].y_pos = -99;
    inds[i].x_cont = -99.9;
    inds[i].y_cont = -99.9;
    for(l=0; l < MAXL; l++){
      inds[i].copy1[l]=-99.9;
      inds[i].copy2[l]=-99.9;
    }
    inds[i].fitness= -99.9;
    inds[i].climate_fit=-99.9;
    inds[i].env_fit=-99.9;
  }

 

  for(int x=0; x < XSIZE; x++){
    for(int y=0; y < YSIZE; y++){
      for(int z=0; z < (1000*K); z++){
	land[x][y].inds_patch[z] = -99;
      }
      land[x][y].no_inds = 0;
    }
  }

  Psize=0;

}



// ----- RECOMBINATION --------------------------------------------------

void recombination(int mum){

  int loc;

  if(inf_cross == false){

    int rcopy, nextcross; 
    int N_crossovers, n_c, n_c2, order;
    int crossovers[MAXL-1];                                  // positions of crossovers
    int sortcross[MAXL];                                     // sorted crossovers
    
    for(int i=0; i<(MAXL-1); i++){
      crossovers[i] = 0;
      sortcross[i] = 0;
    }
    for(loc=0;loc<MAXL;loc++){
      tcopy[loc]=-99.9;
    }
    
    loc=0;
    N_crossovers = 0;
    
    rcopy=random(2);                                         // copy1 or copy2
    N_crossovers=rpoisson(no_cross);                         // random no of crossovers
    if(N_crossovers>(MAXL-2)) N_crossovers=(MAXL-2);         // max crossovers
    
    for(n_c=0; n_c<N_crossovers; n_c++){                     // for each crossover
      crossovers[n_c]=random(MAXL-1)+1;                      // random location of crossover
      
      if(linkage == false && crossovers[n_c]==ENVL) n_c--;   // no crossover between Env and Clim chromosomes, 
      // decided below whether 2 chromosomes split
      
      for(int zz=0; zz<n_c; zz++){                           // check for double numbers
	if(crossovers[n_c] == crossovers[zz]) n_c--; 
      }
    }       
    
    if(linkage == false && random(2)==1) crossovers[N_crossovers] = ENVL;  // do chromosomes split -> yes     
    else crossovers[N_crossovers] = 0;                                     // -> no
    
    for(n_c=0; n_c<N_crossovers; n_c++){         
      order=0;                                
      for(n_c2=0; n_c2<N_crossovers; n_c2++){
	if(crossovers[n_c]>crossovers[n_c2]){
	  order++;                                            // order takes rang of value in
	}                                                     // size hierarchy
      }                                          
      sortcross[order]=crossovers[n_c];
    }
    
    sortcross[N_crossovers+1] = MAXL;
    
    for(int num_c=0; num_c<(N_crossovers+2); num_c++){
      nextcross=sortcross[num_c];
      while(loc<nextcross){                           // all loci smaller than nextcross are copied to tcopy 
	if(rcopy==0) tcopy[loc]=inds[mum].copy1[loc];
	if(rcopy==1) tcopy[loc]=inds[mum].copy2[loc];
	loc++;
      }
      
      if(rcopy==0) rcopy=1;                           // change copies
      else rcopy=0;
    }
    
  }
  
  // for no linkage (inf_link == true)
  else{
    for(loc = 0; loc < MAXL; loc++){
      if(random(2)==1) tcopy[loc] = inds[mum].copy1[loc];
      else tcopy[loc] = inds[mum].copy2[loc];
    }
  }
  
}


// ---- MUTATION --------------------------------------------------------------


void mutation(void){

  int N_mut, n_mut;
  int pos;
  int rcopy;
  bool env;
  double r, change;

  for(int i=0; i<tPsize; i++){         // tPsize = number of offspring (see reprod)

    N_mut=0;
    for(int m = 0; m < MAXL; m++){

      double r;
      ranlxd(&r, 1);
      if(r < mut_rate)	N_mut++;
    }
   
     for(n_mut=0; n_mut<N_mut; n_mut++){  
       
      pos=random(MAXL);                // random position
      rcopy=random(2);                 // random copy

      env=false;                       // check whether locus for environment
      for(int e=0; e<ENVL; e++){
	if(environm[e]==pos) env=true;
      }


      if(env==true){
	rnormal(&r, 1);
 	change= r * mut_env;
	if(rcopy==0)tempI[i].copy1[pos]+=change;   
	else tempI[i].copy2[pos]+=change;
      }

      else{
	rnormal(&r, 1);
	change= r * mut_clim;
	if(rcopy==0)tempI[i].copy1[pos]+=change;   
	else tempI[i].copy2[pos]+=change;
      }

    }
  }
}


// ---- DISPERSAL ---------------------------------------------------------------

void dispersal(void){
  double rdist, dist;

  for(int x=0; x<XSIZE; x++){
    for(int y=0; y<YSIZE; y++){
      land[x][y].no_offs = 0;
    }
  }
  
  for(int i=0; i<tPsize; i++){          

    rnormal(&rdist, 1);
    while(rdist == 1.0) rnormal(&rdist, 1);
    // calculate distance based on normal random value rdist, devide by mean distance of the kernel
    // (exp(loc+(scale^2)/2)) and multiply by mean_disp to get an average distance of mean_disp 
    dist = ((exp(loc+scale*rdist))/(exp(loc+(scale*scale)/2))) * (mean_disp/exp(loc+0.5*scale*scale));
 
    double angle = random(360)*(M_PI/180);
    
    double newx = tempI[i].x_cont + cos(angle) * dist;
    // if there is a gradient and seeds fall out of grid along x-axis they die
    if(gradient > 0.0){
      if(newx > patchsize * XSIZE || newx < 0.0){
	tempI[i].alive=0;
	newx = 0.0 ;
      }
    }
    // otherwise toroidal boundaries
    else{
      newx = fmod(newx+(patchsize*XSIZE*10), (patchsize*XSIZE));
    }

    double newy = tempI[i].y_cont + sin(angle) * dist;
    newy = fmod(newy+(patchsize*YSIZE*10), (patchsize*YSIZE));    
    tempI[i].x_cont = newx;
    tempI[i].y_cont = newy;
    
    tempI[i].x_pos = int (tempI[i].x_cont / patchsize);
    tempI[i].y_pos = int (tempI[i].y_cont / patchsize);
 
    land[tempI[i].x_pos][tempI[i].y_pos].inds_patch[land[tempI[i].x_pos][tempI[i].y_pos].no_offs]=i;
    land[tempI[i].x_pos][tempI[i].y_pos].no_offs++;
  }
}

//--- HARD SELECTION -----------------------------------------------------------

void selection(void){

  int  m_pos, d_pos, match, survive;
  double w, w1, w2, r;
  bool env, clim;

  for(int x=0; x < XSIZE; x++){
    for(int y=0; y < YSIZE; y++){
      land[x][y].no_surv = 0;
    }
  }

  for(int i=0; i<tPsize; i++){

    if(tempI[i].alive==1){
    
      double m_adapt_env = 0.0;
      double m_adapt_clim = 0.0;
      double dist1 = 0.0;
      double dist2 = 0.0;
      double m_cpheno = 0.0;
      double m_epheno = 0.0;
      
      for(int l=0; l<MAXL; l++){
	
	env = false;                       // check whether locus for environment
	for(int e=0; e<ENVL; e++){
	  if(environm[e]==l) env=true;
	}
	
	if(env == false){
	  m_cpheno += tempI[i].copy1[l];
	  m_cpheno += tempI[i].copy2[l];
	}
	else{
	  m_epheno += tempI[i].copy1[l];
	  m_epheno += tempI[i].copy2[l];
	}
      }
      
      // calculate environmental fitness w1 and climate fitness w2 for individuals
      m_adapt_clim = fabs(m_cpheno - land[tempI[i].x_pos][tempI[i].y_pos].climate);
      m_adapt_env  = fabs(m_epheno - land[tempI[i].x_pos][tempI[i].y_pos].environment);

      w1 = exp (-( m_adapt_env * m_adapt_env/(2*varEnv)));
      w2 = exp (-( m_adapt_clim*m_adapt_clim/(2*varClim)));  

      w = w1 * w2;
      if(w < 0.001) w = 0.001;
      if(w > 1.00) w = 1.;
      
      tempI[i].fitness = w;                            // write fitness in temp individuals array
      tempI[i].climate_fit = w2;
      tempI[i].env_fit = w1;
      tempI[i].cpheno = m_cpheno;
      tempI[i].epheno = m_epheno;
      
      ranlxd(&r, 1);                                   // decide whether individual survives or dies
      if(r <= w) survive = 1; 
      else survive = 0;
     
 
      if(survive==1){                                  
	tempI[i].alive = 1;                             // individual is alive
	land[tempI[i].x_pos][tempI[i].y_pos].no_surv++; // ... and added to survivor list
      }
      else{
	tempI[i].alive = 0;                              // otherwise its dead
	tempI[i].env_fit = 0.0;                          // and has 0 fitness
      }
    }
  }
}



// ------ DENSITY-DEPENDENT SURVIVAL AND UPDATE OF LISTS -----------------------------

void dd_survival(void){

  int i, patch;
  double delta, r;                        // density dependent survival probability
  Psize = 0;

  for(int x=0; x < XSIZE; x++){
    for(int y=0; y < YSIZE; y++){
      for(int z=0; z < (100*K); z++){
	land[x][y].inds_patch[z] = -99;
	land[x][y].no_inds = 0;
      }
    }
  } 
  
  for(i=0; i < tPsize; i++){             // tPsize still number of individuals

    if(land[tempI[i].x_pos][tempI[i].y_pos].no_surv > 0){
      delta=(double)K/(double)land[tempI[i].x_pos][tempI[i].y_pos].no_surv;
    }
    else delta = 0.;
    if(delta>1.0) delta=1.0;


    if(tempI[i].alive==1){
      ranlxd(&r, 1);
      if(r < delta){ // if it survives
	inds[Psize]=tempI[i]; // temp ind is written from temp to real inds array

	land[tempI[i].x_pos][tempI[i].y_pos].inds_patch[land[tempI[i].x_pos][tempI[i].y_pos].no_inds] = Psize;
	land[tempI[i].x_pos][tempI[i].y_pos].no_inds++;

	Psize++;
      }
    }
  } 
        
  if(Psize==0){
    gen=999999;                 // to stop generation loop
  }
}

// ---- OUTPUT -------------------------------------------------------------------

void output(void){

  double sum_fit = 0.;
  double sum_c_fit = 0.;
  double sum_e_fit = 0.;
  double ss, ss_e, ss_c = 0.;
  var, var_e, var_c = 0.;

  for(int i=0; i<Psize; i++){
      sum_fit += inds[i].fitness;
      sum_c_fit += inds[i].climate_fit;
      sum_e_fit += inds[i].env_fit;
   }

   mean_fit = sum_fit/Psize;
   env_fit = sum_e_fit/Psize;
   climate_fit = sum_c_fit/Psize;


   for(int i=0; i<Psize; i++){
     ss += (inds[i].fitness-mean_fit) * (inds[i].fitness-mean_fit);
     ss_e += (inds[i].env_fit-env_fit) * (inds[i].env_fit-env_fit);
     ss_c += (inds[i].climate_fit-climate_fit) * (inds[i].climate_fit-climate_fit);
   }
   
  if(Psize > 0) var = ss/Psize;
  if(Psize > 0) var_e = ss_e/Psize;
  if(Psize > 0) var_c = ss_c/Psize;


  for(int x=0; x < XSIZE; x++){
    for(int y=0; y < YSIZE; y++){
      land[x][y].cpheno = 0.0;
      land[x][y].epheno = 0.0;
    }
  }

  for(int x=0; x < XSIZE; x++){
    for(int y=0; y < YSIZE; y++){
      if(land[x][y].no_inds<=0){
	land[x][y].cpheno = 0.0;
	land[x][y].epheno = 0.0;
	land[x][y].maladapt = 0.0;
      }
      else{
	for(int i = 0; i < land[x][y].no_inds; i++){
	  land[x][y].cpheno += inds[land[x][y].inds_patch[i]].cpheno;
	  land[x][y].epheno += inds[land[x][y].inds_patch[i]].epheno;
	  land[x][y].maladapt += inds[land[x][y].inds_patch[i]].climate_fit;
	}
	land[x][y].cpheno = land[x][y].cpheno/(double)land[x][y].no_inds;
	land[x][y].epheno = land[x][y].epheno/(double)land[x][y].no_inds;
	land[x][y].maladapt = land[x][y].maladapt/(double)land[x][y].no_inds;
      }
    }
  }
}




// ------ END -------------------------------------------------------------------
