
/*******************************************************************************
*
* Random number generator "ranlxd"
*
* See the notes 
*   "User's guide for ranlxs and ranlxd [C programs]" (December 1997)
*   "Double precision implementation of the random number 
*    generator ranlux" (December 1997)
* for a detailed description
*
* The externally accessible functions are 
*
*   void ranlxd(double * const r, const int n)
*     Computes the next n single-precision random numbers and 
*     assigns them to the elements r[0],...,r[n-1] of the array r[]
* 
*   void rlxd_init(const int level,const int seed)
*     Initialization of the generator
*
*   void rlxd_get(int * const state)
*     Extracts the current state of the generator and stores the 
*     information in the array state[25]
*
*   void rlxd_reset(const int * state)
*     Resets the generator to the state defined by the array state[25]
*
*   void rnormal(double * const r, cont int n)
*     Computes normally distributed random number with mean 0
*     and variance 1
*
*   int rpoisson(double L)
*     returns a Poisson distributed random number
*
* Version: 2.2
* Author: Martin Luescher <luscher@mail.desy.de>
* Date: 15.07.1999
* 
* Changed by Carsten Urbach <urbach@physik.fu-berlin.de>
* and by Katja Schiffers <katja.schiffers@gmail.com>
*
*******************************************************************************/

#include <limits.h>
#include <float.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
//#include <error.h>
#include "ranlxd.h"

#define _RANLUX_STEP(x1,x2,i1,i2,i3)     \
          x1 = xdbl[i1]-xdbl[i2];        \
          if (x2<0.){                    \
            x1 -= one_bit;               \
            x2 += 1.;                    \
          }                              \
          xdbl[i3] = x2

static int pr,ir,jr,ir_old,init=0;

static double carry;
static double xdbl[12];

static const int next[12] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 0};

static const double dbase = 4294967296.0;		/* 2^32 */
static const double sbase = 16777216.0;		        /* 2^24 */
static const double base = 281474976710656.0;           /* 2^48 */
static const double one_bit = 1.0 / 281474976710656.0;	/* 2^(-48) */
static const double shift = 268435456.0;         	/* 2^28 */

static void error(int no){
  switch(no){
  case 0:
    printf("Error in rlxd_init\n");
    printf("Arithmetic on this machine is not suitable for ranlxd\n");
    break;
  case 1:
    printf("Error in subroutine rlxd_init\n");
    printf("Bad choice of luxury level (should be 0,1 or 2)\n");
    break;
  case 2:
    printf("Error in subroutine rlxd_init\n");
    printf("Bad choice of seed (should be between 1 and 2^31-1)\n");
    break;
  case 3:
    printf("Error in rlxd_get\n");
    printf("Undefined state\n");
    break;
  case 4:
    printf("Error in rlxd_reset\n");
    printf("Arithmetic on this machine is not suitable for ranlxd\n");
    break;
  case 5:
    printf("Error in rlxd_reset\n");
    printf("Unexpected input data\n");
    break;
  }         
  printf("Program aborted\n");
  exit(0);
  }
  

static void update(){
  int k,kmax;
  double y1,y2,y3;
  
  for (k=0; ir>0; ++k){
    y1 = xdbl[jr] - xdbl[ir];
    y2 = y1 - carry;
    if (y2<0.){ 
      carry = one_bit;
      y2 += 1.;
    }
    else{ 
      carry = 0.;
    }
    xdbl[ir] = y2;
    ir = next[ir];
    jr = next[jr];
  }
  
  kmax=pr-12;
  
  for (;k<=kmax;k+=12){
    y1 = xdbl[7]-xdbl[0];
    y1 -= carry;
    
    _RANLUX_STEP(y2, y1, 8, 1, 0);
    _RANLUX_STEP(y3, y2, 9, 2, 1);
    _RANLUX_STEP(y1,  y3,10, 3, 2);
    _RANLUX_STEP(y2, y1,11, 4, 3);
    _RANLUX_STEP(y3, y2, 0, 5, 4);
    _RANLUX_STEP(y1, y3, 1, 6, 5);
    _RANLUX_STEP(y2, y1, 2, 7, 6);
    _RANLUX_STEP(y3, y2, 3, 8, 7);
    _RANLUX_STEP(y1, y3, 4, 9, 8);
    _RANLUX_STEP(y2, y1, 5,10, 9);
    _RANLUX_STEP(y3, y2, 6,11,10);
    
    if (y3<0.){
      carry = one_bit;
      y3 += 1.;
    }
    else{
      carry = 0.;
    }
    xdbl[11] = y3;
  } 
  
  kmax = pr;
  
  for (; k<kmax; ++k){
    y1 = xdbl[jr] - xdbl[ir];
    y2 = y1 - carry;
    if (y2<0.){ 
      carry = one_bit;
      y2 += 1.;
    }
    else{
      carry = 0.;
    }
    xdbl[ir] = y2;
    ir = next[ir];
    jr = next[jr];
  }
  
  ir_old = ir;
}

void rlxd_init(const int level, const int seed){
  int ibit, jbit, k, l, xbit[31];
  int i;
  /* unsigned int i, template=1;*/
  double x, y;

  if ((INT_MAX<2147483647)||(DBL_MANT_DIG<48)){
    error(1);
  }

  if      (level == 0){
    pr = 109;
  }
  else if (level == 1){
    pr = 202;
  }
  else if (level == 2){
    pr = 397;
  }
  else{
    error(2);
  }
  init = 1;
  if (seed <= 0){
    i = 1;
  }
  else{
    i = seed;
  }

  /* xbit[k] \in {0,1} for all k*/
  for (k=0; k<31; ++k){
    xbit[k] = i%2;
    i /= 2;
  }

  if (i!=0){
    error(2);
  }
/*   alternativ: */
/*   well, its faster */
/*   but not really needed here... */
/*   for(k=0; k<31; k++){ */
/*     xbit[k]=((i&template)>>k); */
/*     template<<=1; */
/*   } */

  ibit = 0;
  jbit = 18;
 
  for (k=0;k<12;++k){
    x = 0.;

    /* x becomes maximal 281474976710655=(2^48-1) */
    for (l=0; l<48; ++l){
      y = (double) ((xbit[ibit] + 1) %2);
      x += x+y;
      xbit[ibit] = (xbit[ibit]+xbit[jbit])%2;
      ibit = (ibit+1)%31;
      jbit = (jbit+1)%31;
    }
    xdbl[k] = one_bit*x;
    /* xdbl[k]<=((2^48)-1)*2^(-48)=1-2^(-48) for all k */
  }

  carry = 0.;
  ir = 11;
  jr = 7;
  ir_old = 0;
  /* ir = 11 to cause the generator to call */
  /* update _before_ delivering the first number */
}


void ranlxd(double * const r,const int n){
  int k;
  
  if (init == 0){
    rlxd_init(0,1);
  }

  for (k=0;k<n;++k){
    ir=next[ir];
    if (ir == ir_old){
      update();
    }
    r[k] = xdbl[ir];
  }
}

//--------------



int random(const unsigned int i){   
  return(rand()%i);                   
}


//--------------


void rnormal(double *r, const int n) 
{
 double u[2], s, l;
 int i;

 for(i = 0; i < n; i += 2) {
   ranlxd(u, 2);
   u[0] = 2.*u[0] - 1.;
   u[1] = 2.*u[1] - 1.;
   s = u[0]*u[0]+u[1]*u[1];
   while(s == 0. || s > 1.) {
     ranlxd(u, 2);
     u[0] = 2.*u[0] - 1.;
     u[1] = 2.*u[1] - 1.;
     s = u[0]*u[0]+u[1]*u[1];
   }
   l = sqrt(-2.*log(s)/s);
   r[i] = u[0]*l;
   r[i+1] = u[1]*l;
 }
 return;
}



// ---- POISSON -----

int rpoisson(double L) {

  const int bound = 130;             // safety bound. Must be > L + 8*sqrt(L).
  static double p_L_last = -1.;      // previous value of L
  static double p_f0;                // value at x=0
  double r;                          // uniform random number
  double f;                          // function value
  int x;                             // return value

  if (L != p_L_last) {               // set up
    p_L_last = L;
    p_f0 = exp(-L);
  }                 // f(0) = probability of x=0

  while (1) {  
    ranlxd(&r,1);  
    x = 0;  
    f = p_f0;
    do {                        // recursive calculation: f(x) = f(x-1) * L / x
      r -= f;
      if (r <= 0) return x;
      x++;
      f *= L;
      r *= x;
    }                       // instead of f /= x
    while (x <= bound);
  }
}
//---------



void rlxd_get(int * const state){
  int k;
  double x, y1, y2;

  if (init == 0){
    error(3);
  }

  for (k=0;k<24;++k){
    x = sbase*xdbl[k];
    y1 = sbase*modf(x,&y2);
    state[2*k] = (int)y1;
    state[2*k+1] = (int)y2;
  }

  k = 12*pr+ir;
  k = 12*k+jr;
  k = 24*k+ir_old;
  state[24] = 2*k+(int)(carry*base);
}


void rlxd_reset(const int * state){
  int k;
  double y1, y2;

  if ((INT_MAX<2147483647)||(DBL_MANT_DIG<48)){
    error(4);
  }

  init = 1;

  for (k=0;k<12;++k){
    if ((state[k]>=(int)sbase)||(state[k]<0)){
      error(5);
    }
  }

  k = state[24];
  if (k<0){
    error(5);
  }
  carry = one_bit*(double)(k%2);
  k /= 2;
  ir_old = k%24;
  k /= 24;
  jr = k%12;
  k /= 12;
  ir = k%12;
  pr = k/12;
  
  if (((pr!=109)&&(pr!=202)&&(pr!=397))||
      (jr!=((ir+7)%12))){
    error(5);
  }

  for (k=0;k<12;++k){
    y1 = (double)state[2*k];
    y2 = (double)state[2*k+1];
    xdbl[k] = one_bit*(y1+y2*sbase);
  }
}
