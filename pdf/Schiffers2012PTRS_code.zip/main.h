#ifndef _MAIN_H
#define _MAIN_H


extern void initialise(void); 
extern void climate_change(void);      
extern void recombination(int);     
extern void reproduction(void);
extern void quickie(void);
extern void mutation(void);
extern void dispersal(void);
extern void hard_selection(void);
extern void soft_selection(void);
extern void dd_survival(void);
extern void output(void);

struct patch{                 // one grid cell
  double environment;         // value for environmental conditions
  double climate;             // climatic value
  int no_inds;                // number of adult individuals
  int no_offs;                // number of offspring before selection
  int no_surv;                // number of survivors of selection
  int no_ext;                 // number of extinctions of individuals
  int inds_patch[1000*K];      // list with IDs of individuals
  double cpheno;              // average climatic phenotype of individuals
  double epheno;              // average environmental phenotype of individuals
};

struct individual{
  int alive;                  // 1 for alive, 0 for dead
  int x_pos, y_pos;           // position on landscape grid
  double x_cont, y_cont;      // continuous x, y coordinates
  double copy1[MAXL];         // loci - maternal
  double copy2[MAXL];         // loci - paternal
  double epheno;              // phenotype for environment
  double cpheno;              // phenotype for climate
  double fitness;             // total fitness of individual
  double climate_fit;         // fitness related to climate
  double env_fit;             // fitness related to environment
};

template <typename T> 
T **AllocateDynamicArray( int nRows, int nCols)
{
      T **dynamicArray;

      dynamicArray = new T*[nRows];
      for( int i = 0 ; i < nRows ; i++ )
      dynamicArray[i] = new T [nCols];

      return dynamicArray;
}


template <typename T>
void FreeDynamicArray(T** dArray)
{
      delete [] *dArray;
      delete [] dArray;
}


#endif
